<?php
session_start();
include("db.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
$username=mysqli_real_escape_string($db,$_POST['username']); 
$password=mysqli_real_escape_string($db,$_POST['password']); 
$password=md5($password); 
$sql="SELECT id FROM admin WHERE username='$username' and passcode='$password'";
$result=mysqli_query($db,$sql);
$count=mysqli_num_rows($result);

if($count==1)
{
$_SESSION['username'] = $username;
header("location: myAccount.php");
}
else 
{
echo "<h3 style='color:red;'>Your Login Name or Password is invalid</h3>";
}
}
?>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<center>
<div id="alles">
<form action="login.php" method="post">
<h3>Anmelden</h3>
<label>E-Mail :</label>
<input type="email" name="username"/><br />
<label>Password :</label>
<input type="password" name="password"/><br/>
<input type="submit" value=" Anmelden "/><br />
</form>
</center>
</div>