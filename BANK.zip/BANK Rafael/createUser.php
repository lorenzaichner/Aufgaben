<?php
#### Einbinden der DB Verbindung ###
include("db.php");


if($_SERVER["REQUEST_METHOD"] == "POST")
{
// Username und Passwort vom Formular
$username=mysqli_real_escape_string($db,$_POST['username']); 
$password=mysqli_real_escape_string($db,$_POST['password']);
$kreditrahmen=mysqli_real_escape_string($db,$_POST['rahmen']); 
$password=md5($password); // Passwort mit MD5 verschlüsseln
$sql="Insert into admin(username,kreditrahmen,passcode) values('$username','$kreditrahmen','$password');";
$result=mysqli_query($db,$sql);
echo "<h3 style='color:green;'>Registration Successfully - <a href='login.php'>Zum Login</a></h3>";
}

?>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<center>
<div id="alles">
<form action="createUser.php" method="post">
<h3>create User</h3>
<label>UserName(E-Mail) :</label>
<input type="email" name="username"/><br />


<label>Password :</label>
<input type="password" name="password"/><br/>

<label>Kreditrahmen :</label>
<input type="number" name="rahmen"/><br />

<input type="submit" value=" Benutzer erstellen "/><br />
</form>
</center>
</div>